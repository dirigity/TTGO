// => Hardware select
// #define LILYGO_WATCH_2019_WITH_TOUCH        // To use T-Watch2019 with touchscreen, please uncomment this line
// #define LILYGO_WATCH_2019_NO_TOUCH       // To use T-Watch2019 Not touchscreen , please uncomment this line
// #define LILYGO_WATCH_BLOCK               // To use T-Watch Block , please uncomment this line
// #define LILYGO_WATCH_2020_V1
#define LILYGO_WATCH_2020_V2
// #define LILYGO_WATCH_2020_V3

#ifdef LILYGO_WATCH_2019_WITH_TOUCH
#define LILYGO_WATCH_HAS_MOTOR

#endif
#include <LilyGoWatch.h>




